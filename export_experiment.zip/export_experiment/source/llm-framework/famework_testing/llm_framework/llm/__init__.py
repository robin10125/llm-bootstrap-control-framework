"""LLM backend helpers."""

