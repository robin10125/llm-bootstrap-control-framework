"""LLM action interface implementations."""

